// Function to open the modal
function openModal(imageSrc) {
  document.getElementById("modalImage").src = imageSrc;
  document.getElementById("myModal").style.display = "block";

}
// Function to close the modal
function closeModal() {
  document.getElementById("myModal").style.display = "none";

}

// Close the modal when the user clicks anywhere outside of the modal
window.onclick = function (event) {
  if (event.target == document.getElementById("myModal")) {
    closeModal();
  }

}

function showTable(tabId) { 
  const sections = document.querySelectorAll('.styled-table'); 
  sections.forEach(section => { 
      section.style.display = 'none'; 
  }); 
  const selectedSection = document.getElementById(tabId); 
  if (selectedSection) { 
      selectedSection.style.display = 'table'; 
  } 
  const tabs = document.querySelectorAll('.tableIndex p'); 
  tabs.forEach(tab => { tab.classList.remove('selected'); 

  }); 
  const selectedTab = document.getElementById(tabId + '_Tab'); 
  if (selectedTab) { 
      selectedTab.classList.add('selected'); 
  }
} 
document.getElementById('KYD_Tab').addEventListener('click', function() { 
    showTable('KYD'); 
}); 
document.getElementById('SDV_Tab').addEventListener('click', function() { 
    showTable('SDV'); 
}); 

showTable('KYD'); // Show Waterfall table by default